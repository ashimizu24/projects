To run the program, run index.jsp located in WebContent/jsp and choose Assignment_Test.json
as the file. 
Once accepted, the program is redirected to home.jsp.

These are the jsp/sevlets the AJAX calls are called in with the corresponding html jsps
home.jsp -> (inside src/servlets) highlightHome.java
lectures.jsp -> topicHighlight.jsp 
assignments.jsp -> sortAssignments.jsp
