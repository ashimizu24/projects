package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import objects.DataContainer;
import objects.Lecture;
import objects.Topic;
import objects.Week;
import parsing.StringConstants;

/**
 * Servlet implementation class highlightTopics
 */
@WebServlet("/HighlightTopics")
public class highlightTopics extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String search = (request.getParameter("topic")).toLowerCase(); 
		String button = request.getParameter("show");
		
		System.out.println("search: " + search + " button: " + button);
		ArrayList<String> topic_names = new ArrayList<String>();
		boolean found = false;
		
		DataContainer school = (DataContainer) request.getSession().getAttribute(StringConstants.DATA);
		List<Week> weeks = school.getSchools().get(0).getDepartments().get(0).getCourses().get(0).getSchedule().getWeeks();
		for(int i=0; i<weeks.size(); i++) {
			List<Lecture> lec = weeks.get(i).getLectures();
			for(int j=0; j<lec.size(); j++) {
				List<Topic> topics = lec.get(j).getTopics();
				for(int t=0; t<topics.size(); t++) {
					if(((topics.get(t).getTitle().toLowerCase())).contains(search)) {
						found = true;
						topic_names.add(topics.get(t).getTitle());
					}
				}
			}
		}
		
		PrintWriter pw = response.getWriter();
		
		String show = request.getParameter("show");
		pw.println(show);
		
		if(found) {
		   	
	     	if(topic_names != null) {
	     		for(int n=0; n<topic_names.size(); n++) {
	     			System.out.print(topic_names.get(n));
	     			pw.println(topic_names.get(n) + "\n");
	     		}
	     	}
	     	
		}
		pw.flush();
		pw.close();
	}

}
