package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import objects.DataContainer;
import objects.StaffMember;
import parsing.StringConstants;


/**
 * Servlet implementation class highlightHome
 */
@WebServlet("/HighlightHome")
public class highlightHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = (request.getParameter("name")).toLowerCase(); 
		String return_name = "";
		boolean found = false;
		
		DataContainer school = (DataContainer) request.getSession().getAttribute(StringConstants.DATA);
		List<StaffMember> staff = school.getSchools().get(0).getDepartments().get(0).getCourses().get(0).getStaffMembers();
		for(int i=0; i<staff.size(); i++) {
			if(name.contains((staff.get(i).getName().getFirstName()).toLowerCase()) || name.contains((staff.get(i).getName().getLastName().toLowerCase()))){
				found = true;
				return_name = staff.get(i).getName().getFirstName() + " " + staff.get(i).getName().getLastName();
				break;
			}
		}
		
		if(found) {
		   	PrintWriter pw = response.getWriter();
	     	
	    		pw.println(return_name);
	   
	    		pw.flush();
	    		pw.close();
		}	
	}

}