package objects;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


public class Assignment extends GeneralAssignment {
	private String assignedDate;
	private String url;
	private List<File> gradingCriteriaFiles;
	private List<File> solutionFiles;
	private List<Deliverable> deliverables;

	public String getAssignedDate() {
		return assignedDate;
	}

	public String getUrl() {
		return url;
	}

	public List<Deliverable> getDeliverables() {
		return deliverables;
	}

	public List<File> getGradingCriteriaFiles() {
		return gradingCriteriaFiles;
	}

	public List<File> getSolutionFiles() {
		return solutionFiles;
	}
	
	
	private class TitleSort implements Comparator<Deliverable>{
		public int compare(Deliverable a, Deliverable b){
			if(a.getTitle() != null && b.getTitle() != null) {
				return ((a.getTitle()).compareTo(b.getTitle()));
			}
    			return 0;
		}
	}
	
	private class DueDateSort implements Comparator<Deliverable>{
		public int compare(Deliverable a, Deliverable b) {
			if(a.getDueDate() != null && b.getDueDate() != null) {
				Scanner scan = new Scanner(a.getDueDate());
		     	Scanner scan2 = new Scanner(b.getDueDate());
				scan.useDelimiter("-");
				scan2.useDelimiter("-");
					 
				while(scan.hasNext() && scan2.hasNext()){
					int c = Integer.parseInt(scan.next());
					int d = Integer.parseInt(scan2.next());
					
					if(c < d) {
						scan.close();
						scan2.close();
						return 5;
					 }
					else if (c > d) {
						scan.close();
						scan2.close();
						return -5;
					}
				}
				scan.close();
				scan2.close();
			}
			return 0;
		}
			
	}
	
	private class GradeSort implements Comparator<Deliverable>{
		
		public int compare(Deliverable a, Deliverable b) {
			if(a.getGradePercentage() != null && b.getGradePercentage() != null) {
				Scanner scan = new Scanner(a.getGradePercentage());
		     	Scanner scan2 = new Scanner(b.getGradePercentage());
				scan.useDelimiter("\\%");
				scan2.useDelimiter("\\%");
				
				double c = Double.parseDouble(scan.next());
				double d = Double.parseDouble(scan2.next());
				if(c < d) {
					scan.close();
					scan2.close();
					return 5;
				 }
				else if (c > d) {
					scan.close();
					scan2.close();
					return -5;
				}
				scan.close();
				scan2.close();
			}
			
			return 0;
		}
	}
	
	public void sortByTitle(List<Deliverable> deliverables) {
		Collections.sort(deliverables, new TitleSort());
	}
	
	public void sortByDueDate(List<Deliverable> deliverables) {
		Collections.sort(deliverables, new DueDateSort());
	}
	
	public void sortByGrade(List<Deliverable> deliverables) {
		Collections.sort(deliverables, new GradeSort());
	}

}
